package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithMysqlComposeApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithMysqlComposeApplication.class, args);
	}

}
